import java.util.Scanner;

public class Items {

	public static void main(String[] args) {
       String[] items=new String[11]; 
       int price []=new int[11];
       int j =0;
       items[0]="Poha";
       items[1]="Kachori";
       items[2]="Samosa";
       items[3]="Aloo bada";
       items[4]="Bread bada";
       items[5]="Pani puri";
       items[6]="Sev puri";
       items[7]="Chole tikiya";
       items[8]="Dahi puri";
       items[9]="Cold Drink";
       
       price[0]=12;
       price[1]=12;
       price[2]=12;
       price[3]=20;
       price[4]=20;
       price[5]=10;
       price[6]=10;
       price[7]=15;
       price[8]=15;
       price[9]=60;
      
      System.out.println("Choose what you want to eat");
      System.out.println("***************************************************************************");

      for (int i = 0; i < price.length-1; i++) {
		System.out.println(i+". "+items[i]+":"+" price: "+price[i]);
		
	}
      System.out.println("***************************************************************************");

      System.out.println("Press respective S.No number to select");
      Scanner sc = new Scanner(System.in);
      int order[] = new int[10];
      for (int i = 0; i < order.length; i++) {
    	  order[i]=-1;
      }
      for (int i = 0; i < order.length; i++) {
    	  System.err.println("select item");
		order[i]=sc.nextInt();
		if(order[i]<0||order[i]>10) {
			System.err.println("There is no item like that");
			System.out.println("Please select item from menu");
			break;
		}
		System.out.println("want to order more items press y or n");
		String flag = sc.next();
	
		
		if(flag.matches("n")) {
			System.out.println("ThankYou for ordering.  calculating your bill......");
			i=20;
		}
	}
     
      
      for (int i = 0; i < order.length; i++) {
    	 
    	if(order[i]>=0)
		j=j+price[order[i]];
    	
		
	}
      System.out.println(j+" is your final amount");
      
      
      
	}

}
